# 8_Puzzle_Problem

The plan is designed to solve an 8-puzzle using an A *search algorithm. A * is a recursive algorithm that is called up until an answer is found. Considering two heuristic features, misplaced heuristic and manhattan heuristic.

By combining the start state and the goal state, the program utilizes the two approaches to discover the finest solution route to achieve the goal state. Also with the number of nodes produced and expanded to achieve the goal state
